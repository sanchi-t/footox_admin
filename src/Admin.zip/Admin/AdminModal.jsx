import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  useDisclosure,
  Button,
  FormLabel,
  Input,
} from "@chakra-ui/react";

import { updateData } from "../redux/DataReducer/action";
import { EditIcon, Icon } from "@chakra-ui/icons";

import axios from 'axios';
import { Box,  Flex,  Heading, Text } from "@chakra-ui/react";
import { useEffect } from "react";
import {useRef ,useState } from "react";
import {useNavigate} from 'react-router-dom';
import { useLocation } from 'react-router-dom';

import { useDispatch, useSelector } from "react-redux";
import swal from 'sweetalert';

export function AdminUpdate({ id, products, dispatch, getData }) {
  const [CSV, setCSV] = useState("");
 
  const { isOpen, onOpen, onClose } = useDisclosure();
  
  const handleCSV = (e) => {
    setCSV(e.target.files[0])
  }
  const handleSubmit = (e) =>{
   
    
    e.preventDefault();
    console.log(CSV);

  
    const CSVData = new FormData();

   
       
        CSVData.append('CSVFile', CSV);

        axios.post('http://localhost:4000/admin5/', CSVData).then(res => {
            console.log(res.status);
            // if (res.data.status === 200) {
                swal("Success", res.data.message, "success");
        });
     
  }


  return (
    <>
      <Button colorScheme='teal' variant='outline' onClick={onOpen}>
        Bulk Upload
      </Button>
      <Modal isOpen={isOpen} onClose={onClose}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader></ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <form onSubmit={handleSubmit} enctype="multipart/form-data">
              {/* <FormLabel>Name</FormLabel> */}
              <input
                type={'file'}
                
                onChange={handleCSV}
              
              />
              <ModalFooter>
                <Button bg={"teal"} color={"white"} mr={1} type="submit" onClick={onClose}>
                  Upload
                </Button>
                
              </ModalFooter>
            </form>
          </ModalBody>
        </ModalContent>
      </Modal>
    </>
  );
}
